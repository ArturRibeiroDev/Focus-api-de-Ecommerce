# Focus Tech — API de E-commerce

API REST para cadastro, autenticação, catálogo, carrinho e pedidos, construída para o desafio de backend da Focus Tech.

## Tecnologias e arquitetura

- Node.js, TypeScript 7, Express 5, Zod 4, Prisma 7 e PostgreSQL.
- JWT para autenticação e bcrypt para hash de senhas.
- Separação modular em rotas, controllers, services, repositories, schemas e middlewares.
- PostgreSQL foi escolhido por ser relacional e oferecer transações, constraints, locks de linha e `NUMERIC` para preservar integridade e valores monetários.

## Estrutura

```text
src/
  Middlewares/       autenticação, validação e erros
  config/            cliente Prisma e configuração JWT
  modules/           auth, users, products, carts, checkout, orders
  routes.ts          composição das rotas
prisma/              schema e migrations
tests/               testes automatizados de schemas
```

## Requisitos e configuração

Requer Node.js compatível com TypeScript 7 e PostgreSQL. Copie `.env.example` para `.env` e informe as configurações locais:

```env
APP_PORT=3000
APP_ENV=development
DATABASE_URL=postgresql://user:password@localhost:5432/ecommerce
JWT_SECRET=use-uma-chave-aleatoria-com-pelo-menos-32-bytes
JWT_EXPIRES_IN=1d
BCRYPT_SALT_ROUNDS=12
```

Não compartilhe `.env`. Ele é ignorado pelo Git. Instale e inicialize:

```bash
npm ci
npx prisma generate
npx prisma migrate deploy
npm run dev
```

O servidor usa `PORT` atualmente; defina `PORT=3000` ao executar ou ajuste o serviço para `APP_PORT`. Antes de usar migrations em qualquer banco existente, faça backup e revise a seção de compatibilidade abaixo.

## Comandos

```bash
npm run typecheck
npm run build
npm test
npx prisma validate
npx prisma generate
```

`npm test` executa testes automatizados de validação de entrada. Ainda não há uma suíte HTTP de integração conectada a um PostgreSQL descartável.

## Rotas

Todas as rotas usam o prefixo `/api`. Rotas protegidas requerem `Authorization: Bearer <accessToken>`.

| Método | Rota | Acesso | Descrição |
|---|---|---|---|
| POST | `/auth/register` | público | Cadastra usuário |
| POST | `/auth/login` | público | Emite JWT |
| GET | `/users/me` | JWT | Consulta o próprio usuário |
| GET | `/products?page=1&limit=10&search=notebook` | público | Lista produtos ativos |
| GET | `/products/:id` | público | Consulta produto ativo |
| POST | `/products` | JWT | Cria produto |
| PUT/PATCH | `/products/:id` | JWT | Atualiza produto |
| DELETE | `/products/:id` | JWT | Desativa produto (204) |
| GET | `/cart` | JWT | Consulta carrinho |
| POST | `/cart/items` | JWT | Adiciona item |
| PUT | `/cart/items/:productId` | JWT | Altera quantidade |
| DELETE | `/cart/items/:productId` | JWT | Remove item (204) |
| POST | `/checkout` | JWT | Cria pedido pago simulado |
| GET | `/orders` | JWT | Lista pedidos do usuário |

Cadastro: `POST /api/auth/register` com `{ "name": "Eduarda", "email": "eduarda@example.com", "password": "SenhaForte123!" }` retorna `201` sem a senha.

Login: `POST /api/auth/login` com e-mail e senha retorna `{ "accessToken": "…", "tokenType": "Bearer" }`. Credenciais inválidas retornam `401` genérico.

Produto requer `name`, `description`, `price`, `stock` (opcional, padrão 0) e `categoryId` inteiro positivo. O endpoint de listagem retorna `data` e `pagination` com `page`, `limit`, `total`, `totalPages` e flags de navegação.

O carrinho retorna `items` com `productId`, `name`, `quantity`, `unitPrice` e `subtotal`, mais `total`. Adicionar um produto existente soma as quantidades, sujeito ao estoque. Valores monetários são retornados como strings decimais.

## Regras de negócio e concorrência

- O cadastro cria um carrinho e armazena apenas hash bcrypt.
- Cada usuário tem um carrinho; a constraint única e a chave composta evitam carrinhos/itens duplicados.
- Produto removido é marcado inativo. Consultas públicas não retornam itens inativos e pedidos antigos preservam a referência ao produto.
- Checkout grava pedido, snapshots de preço, estoque e limpeza do carrinho dentro de uma transação. O estoque é decrementado por atualização condicional (`stock >= quantidade`), impedindo saldo negativo.
- A linha do carrinho é bloqueada durante adição, atualização e remoção; checkouts concorrentes do mesmo usuário aguardam e o segundo não consegue repetir itens já consumidos.
- Pedidos são filtrados pelo usuário derivado do JWT e ordenados do mais recente para o mais antigo.
- Erros seguem `{ "error": { "code": "...", "message": "..." } }`.

## Compatibilidade das migrations — atenção

O histórico legado não correspondeu ao schema atual: a migration inicial declara IDs `TEXT`, e a migration `20261006002442_ajuste_na_category` remove e recria `category_id` como inteiro, com aviso explícito de perda de dados. Foi adicionada uma migration posterior que converte os IDs textuais remanescentes com mapeamento de chaves e referências. As migrations antigas não foram editadas.

Esse caminho ainda precisa ser reproduzido contra PostgreSQL descartável antes de ser aplicado: o ambiente desta execução não forneceu uma URL confirmada de banco de teste e nenhuma migration foi executada. Em banco existente, não execute `migrate reset`, `db push` nem aplique a conversão antes de backup e ensaio em cópia. O caminho de recriação ainda pode falhar ou exigir recuperação manual em bases com dados anteriores à migration de categoria, pois a migration histórica descarta `category_id`.

## Erros

`400 VALIDATION_ERROR` para entradas inválidas, `401` para autenticação inválida, `404` para recursos ausentes, `409 EMAIL_ALREADY_EXISTS` para e-mail duplicado e `500 INTERNAL_ERROR` para falhas inesperadas. Erros internos não incluem stack trace na resposta.

## Estado de validação

Confira os resultados do diagnóstico e da validação final no relatório de entrega desta alteração. Testes HTTP de integração, concorrência real e reconstrução das migrations ainda dependem de um PostgreSQL temporário isolado.
